@javax.xml.bind.annotation.XmlSchema(namespace = "http://tomcat_applicationlevelsecurity.ws.javaee.edu/")
package edu.javaee.ws.client;
