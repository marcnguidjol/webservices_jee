/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.javaee.ws.tomcat_securityclient;

import java.io.IOException;
import java.util.Collections;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

/**
 *
 * @author ngj
 */
public class AuthenticationDataInputHandler implements SOAPHandler<SOAPMessageContext>{

    @Override
    public Set<QName> getHeaders() {
        return Collections.EMPTY_SET;
    }

    @Override
    public boolean handleMessage(SOAPMessageContext context) {
         Boolean outBoundProperty = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
        //only in case of outgoing msg
        if (outBoundProperty) {
            SOAPMessage message = context.getMessage();
            try {
                SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
                SOAPHeader header = envelope.getHeader();
                SOAPHeader newHeader;
                if (null == header) {
                    //add new header in envelope
                    newHeader = envelope.addHeader();
                } else {
                    //add 2 headers username + passwdord in envelope
                    newHeader = envelope.getHeader();
                    QName usernameQName = new QName("http://handlerws.ws.javaee.edu/", "username");
                    SOAPHeaderElement userHeaderElement = newHeader.addHeaderElement(usernameQName);
                    userHeaderElement.setActor(SOAPConstants.URI_SOAP_ACTOR_NEXT);
                    userHeaderElement.addTextNode("tomcat");
                    QName pwQName = new QName("http://handlerws.ws.javaee.edu/", "password");
                    SOAPHeaderElement pwHeaderElement = newHeader.addHeaderElement(pwQName);
                    pwHeaderElement.setActor(SOAPConstants.URI_SOAP_ACTOR_NEXT);
                    pwHeaderElement.addTextNode("tomcat");  //Base64???
                    message.saveChanges();
                    System.out.println("--- Writing modified SOAP Message to output ---");
                    message.writeTo(System.out);
                }
            } catch (SOAPException ex) {
                Logger.getLogger(AuthenticationDataInputHandler.class.getName()).log(Level.SEVERE, ex.getMessage(), ex);
            } catch (IOException ex) {
                Logger.getLogger(AuthenticationDataInputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return true;
    }

    @Override
    public boolean handleFault(SOAPMessageContext context) {
        return true;
    }

    @Override
    public void close(MessageContext context) {
        
    }
    
}
