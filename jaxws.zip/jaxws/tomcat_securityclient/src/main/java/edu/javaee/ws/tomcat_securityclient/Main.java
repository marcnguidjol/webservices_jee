package edu.javaee.ws.tomcat_securityclient;

import edu.javaee.ws.client.SayHelloWS;
import edu.javaee.ws.client.SayHelloWSService;
import java.util.List;
import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;

/**
 * Tomcat Client with appl. level auth providing username + password in headers
 * of request
 *
 * @author ngj
 */
public class Main {

    public static void main(String[] args) {
        
        SayHelloWSService sayHelloWSService = new SayHelloWSService();
        SayHelloWS port = sayHelloWSService.getSayHelloWSPort();
        
        Binding binding = ((BindingProvider) port).getBinding();
        List<Handler> handlerChain = binding.getHandlerChain();
        handlerChain.add(new AuthenticationDataInputHandler());
        binding.setHandlerChain(handlerChain);
        
        final String response = port.greet("Marc Nguidjol");
        System.out.println("--- GREETING from secure Tomcat: '" + response + "' ---");
    }

}
