package edu.javaee.ws.asynchronesws;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.validation.constraints.NotNull;

/**
 * WS PersonenSuche
 * @author ngj
 */
@WebService(name = "personenSucheWS")
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT, use = SOAPBinding.Use.LITERAL)
public interface PersonenSucheIF {

    /**
     * Web service operation
     *
     * @param nickname
     * @return
     * @throws edu.javaee.ws.asynchronesws.PersonNotFoundException
     */
    @WebMethod(operationName = "findPersonByNickname")
    Person findPersonByNickname(@NotNull final String nickname) throws PersonNotFoundException;
    
}
