package edu.javaee.ws.asynchronesws;

/**
 * Exception Class
 *
 * @author ngj
 */
public class PersonNotFoundException extends Exception {

    public PersonNotFoundException(String message) {
        super(message);
    }

}
