package edu.javaee.ws.asynchronesws;

import javax.inject.Inject;
import javax.jws.WebService;
import javax.validation.constraints.NotNull;

/**
 * PersonenSucheWS (asynchrones WS)
 *
 * @author ngj
 */
@WebService(
        endpointInterface = "edu.javaee.ws.asynchronesws.PersonenSucheIF", 
        targetNamespace = "http://ws.jaxws.edu",
        serviceName = "personenSucheWS"
)
public class PersonenSucheWS implements PersonenSucheIF {

    @Inject
    PersonenRepository repo;

    /**
     * Web service operation
     *
     * @param nickname
     * @return
     * @throws edu.javaee.ws.asynchronesws.PersonNotFoundException
     */
    @Override
    public Person findPersonByNickname(@NotNull final String nickname) throws PersonNotFoundException {
        Person found = repo.getPersonByNickName().values().
                stream().
                filter(p -> p.getNickName().equalsIgnoreCase(nickname)).
                findFirst().
                orElse(null);
                if(null == found){
            throw new PersonNotFoundException("No Person found with given Nickname '" + nickname + "' in Repository!");
        }    
        return found;
    }

}
