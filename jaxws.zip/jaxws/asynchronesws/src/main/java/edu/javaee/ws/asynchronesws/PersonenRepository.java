package edu.javaee.ws.asynchronesws;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;

/**
 * Repository
 *
 * @author ngj
 */
@ApplicationScoped
public class PersonenRepository {

    private final Map<String, Person> personByNickName = new HashMap<>();

    @PostConstruct
    public void init() {
        this.personByNickName.put("ngj", new Person("ngj", "Marc", "Nguidjol", "marcnguidjol@gmail.com"));
        this.personByNickName.put("maxmustermann", new Person("maxmustermann", "Max", "Mustermann", "maxmustermann@gmail.com"));
    }

    public Map<String, Person> getPersonByNickName() {
        return personByNickName;
    }

}
