package edu.javaee.ws.handlerws;

import java.time.LocalDateTime;
import javax.jws.HandlerChain;
import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * Server Time WS
 * @author ngj
 */
@WebService
@HandlerChain(file = "handlers.xml")
public class ServerZeitWS {

    /**
     * Web service operation
     * @return 
     */
    @WebMethod(operationName = "getLocalTimeAndDate")
    public String getLocalTimeAndDate() {
        LocalDateTime now = LocalDateTime.now();
        return now.toString();
    }
    
}
