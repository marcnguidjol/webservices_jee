package edu.javaee.ws.handlerws;

import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.namespace.QName;
import javax.xml.soap.Node;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import javax.xml.ws.soap.SOAPFaultException;
import org.apache.commons.lang3.StringUtils;

/**
 * SOAP Handler checking secret in header of incoming soap message
 *
 * @author ngj
 */
public class SecretValueValidatorHandler implements SOAPHandler<SOAPMessageContext> {

    private static final String SECRET = "BITTE";

    @Override
    public Set<QName> getHeaders() {
        return Collections.EMPTY_SET;
    }

    @Override
    public boolean handleMessage(SOAPMessageContext context) {
        System.out.println("--- edu.javaee.ws.handlerws.SecretValidator.handleMessage() ---");
        // Incoming or outgoing message? true = outgoing, false = incoming
        Boolean outBoundProperty = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
        if (!outBoundProperty) {
            SOAPMessage incomingSOAPMessage = context.getMessage();
            if (null != incomingSOAPMessage) {
                try {
                    SOAPEnvelope envelope = incomingSOAPMessage.getSOAPPart().getEnvelope();
                    //Header elements?
                    SOAPHeader header = envelope.getHeader();
                    Iterator extractedAllHeaderElements = header.extractAllHeaderElements();
                    if (null != extractedAllHeaderElements) {
                        if (!extractedAllHeaderElements.hasNext()) {
                            SOAPBody body = envelope.getBody();
                            SOAPFault fault = body.addFault();
                            fault.setFaultCode("400");
                            fault.setFaultString("No SECRET given");
                            throw new SOAPFaultException(fault);
                        }
                        while (extractedAllHeaderElements.hasNext()) {
                            Node node = (Node) extractedAllHeaderElements.next();
                            final String nodeName = node.getNodeName();
                            final String secretFound = node.getValue();
                            if (StringUtils.isNotEmpty(secretFound)) {
                                if (secretFound.equalsIgnoreCase(SECRET)) {
                                    System.out.println("--- Correct SECRET given, printing out soap message on console ---");
                                    incomingSOAPMessage.writeTo(System.out);
                                } else {
                                    //write fault message
                                    SOAPBody body = envelope.getBody();
                                    SOAPFault fault = body.addFault();
                                    fault.setFaultCode("400");
                                    fault.setFaultString("Invalid SECRET");
                                    throw new SOAPFaultException(fault);
                                }
                            }
                        }
                    }
                } catch (SOAPException ex) {
                    Logger.getLogger(SecretValueValidatorHandler.class.getName()).log(Level.SEVERE, ex.getMessage(), ex);
                } catch (IOException ex) {
                    Logger.getLogger(SecretValueValidatorHandler.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return true;
    }

    @Override
    public boolean handleFault(SOAPMessageContext context) {
        return true;
    }

    @Override
    public void close(MessageContext context) {

    }

}
