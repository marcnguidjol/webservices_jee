package edu.javaee.ws.handlerws;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.Set;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

/**
 * Logging Handler printing incoming messages
 *
 * @author ngj
 */
public class CustomLoggingMsgHandler implements SOAPHandler<SOAPMessageContext> {

    @Override
    public boolean handleMessage(SOAPMessageContext messageContext) {
        logToSystemOut(messageContext);
        return true;
    }

    @Override
    public Set<QName> getHeaders() {
        return Collections.EMPTY_SET;
    }

    @Override
    public boolean handleFault(SOAPMessageContext messageContext) {
        return true;
    }

    @Override
    public void close(MessageContext context) {
    }

    private void logToSystemOut(SOAPMessageContext messageContext) {
        Boolean outboundProperty = (Boolean) messageContext.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
        try {
            if (!outboundProperty) {
                SOAPMessage msg = messageContext.getMessage();
                System.out.println("Incoming SOAP message:");
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                msg.writeTo(stream);
                System.out.println(stream.toString());
                System.out.println("=====================================");
            }
        } catch (IOException | SOAPException e) {
            System.err.println("Exception in CustomLoggingHandler: " + e);
        }
    }

}
