package edu.javaee.ws.asynchronesclient;

import edu.javaee.ws.client.FindPersonByNickname;
import edu.javaee.ws.client.FindPersonByNicknameResponse;
import edu.javaee.ws.client.Person;
import edu.javaee.ws.client.PersonenSucheWS;
import edu.javaee.ws.client.PersonenSucheWS_Service;
import java.util.concurrent.ExecutionException;
import javax.xml.ws.Response;

/**
 * Asynchroner WS Aufruf
 * @author ngj
 */
public class Main {
    
    public static void main(String[] args) throws InterruptedException, ExecutionException{
        PersonenSucheWS_Service personenSucheWS_Service = new PersonenSucheWS_Service();
        PersonenSucheWS personenSucheWSPort = personenSucheWS_Service.getPersonenSucheWSPort();
        
        FindPersonByNickname findPersonByNickname = new FindPersonByNickname();
        findPersonByNickname.setArg0("ngj");
        
        Response<FindPersonByNicknameResponse> findPersonByNicknameAsync = personenSucheWSPort.findPersonByNicknameAsync(findPersonByNickname);
        while(!findPersonByNicknameAsync.isDone()){
            Thread.sleep(10L);
            System.out.println("--- Retrying after 10 ms to get response from asynchronous ws call ---");
        }
        FindPersonByNicknameResponse response = findPersonByNicknameAsync.get();
        if(null != response){
            Person foundPerson = response.getReturn();
            System.out.printf("--- FirstName '%s' ---", foundPerson.getFirstName());
            System.out.printf("--- LastName '%s' ---", foundPerson.getLastName());
            System.out.printf("--- Em@il '%s' ---", foundPerson.getEmail());
            
        }
    }
    
}
