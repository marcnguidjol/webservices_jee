@javax.xml.bind.annotation.XmlSchema(namespace = "http://asynchronesws.ws.javaee.edu/")
package edu.javaee.ws.client;
