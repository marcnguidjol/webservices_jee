@javax.xml.bind.annotation.XmlSchema(namespace = "http://handlerws.ws.javaee.edu/")
package edu.javaee.ws.client;
