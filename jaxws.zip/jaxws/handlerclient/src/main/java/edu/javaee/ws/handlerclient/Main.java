package edu.javaee.ws.handlerclient;

import edu.javaee.ws.client.ServerZeitWS;
import edu.javaee.ws.client.ServerZeitWSService;

/**
 * Main
 *
 * @author ngj
 */
public class Main {

    public static void main(String[] args) {
        ServerZeitWSService serverZeitWSService = new ServerZeitWSService();
        ServerZeitWS serverZeitWSPort = serverZeitWSService.getServerZeitWSPort();
        String localTimeAndDate = serverZeitWSPort.getLocalTimeAndDate();
        System.out.printf("--- WS response '%s' ---", localTimeAndDate);
    }

}
