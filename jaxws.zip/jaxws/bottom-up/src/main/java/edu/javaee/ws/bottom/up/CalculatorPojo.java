package edu.javaee.ws.bottom.up;

import java.math.BigInteger;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.validation.constraints.NotNull;

/**
 * Simple POJO with JAXWS Annotations as Webservice
 * @author ngj
 */
@WebService(
        name = "Calculator", 
        serviceName = "CalculatorWS", 
        portName = "CalculatorIF", 
        targetNamespace = "http://ws.jaxws.edu")
public class CalculatorPojo {

    /**
     * Web service operation add2IntegerNumbers
     * @param firstNumber
     * @param secondNumber
     * @return 
     */
    @WebMethod(operationName = "add")
    public BigInteger add2IntegerNumbers(@NotNull Integer firstNumber, @NotNull Integer secondNumber) {
        int firstIntValue = firstNumber;
        int secondIntValue = secondNumber;
        int sum = firstIntValue + secondIntValue;
        return new BigInteger(String.valueOf(sum));
    }
    
}
