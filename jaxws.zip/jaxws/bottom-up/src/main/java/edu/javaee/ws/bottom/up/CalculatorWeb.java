package edu.javaee.ws.bottom.up;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.validation.constraints.NotNull;

/**
 * Simple POJO with JAXWS Annotations as Webservice for Tomcat
 *
 * @author ngj
 */
@WebService(
        name = "Calculator",
        serviceName = "CalculatorWS",
        portName = "CalculatorIF",
        targetNamespace = "http://ws.jaxws.edu")
public class CalculatorWeb {

    /**
     * Web service operation add2IntegerNumbers
     *
     * @param firstNumber
     * @param secondNumber
     * @return
     */
    @WebMethod(operationName = "add")
    public long add2IntegerNumbers(@NotNull int firstNumber, @NotNull int secondNumber) {
        int firstIntValue = firstNumber;
        int secondIntValue = secondNumber;
        long sum = firstIntValue + secondIntValue;
        return sum;
    }
}
