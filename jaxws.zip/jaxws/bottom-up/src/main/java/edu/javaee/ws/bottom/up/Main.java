package edu.javaee.ws.bottom.up;

import javax.xml.ws.Endpoint;

/**
 * Endpoint Publisher for Webservice CalculatorPojo
 * @author ngj
 */
public class Main {
    
    final static String CALCULATOR_WS_URI = "http://localhost:9090/ws-bottomup/CalculatorWS";
    
    public static void main(String[] args){
        CalculatorPojo myCalculatorWS = new CalculatorPojo();
        Endpoint endpointCalculatorWS = Endpoint.publish(CALCULATOR_WS_URI, myCalculatorWS);
        if(endpointCalculatorWS.isPublished()){
            System.out.printf("--- CalculatorWS with JRE published: %s" , 
                    endpointCalculatorWS.getEndpointReference().toString());
        }
    }
    
}
