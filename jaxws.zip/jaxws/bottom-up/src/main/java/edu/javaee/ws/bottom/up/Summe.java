package edu.javaee.ws.bottom.up;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Ergebnis der Addition zweier ganze Zahlen
 *
 * @author ngj
 */
@XmlRootElement
public class Summe {

    private BigInteger sum;

    public Summe() {
    }

    public Summe(BigInteger sum) {
        this.sum = sum;
    }

    public BigInteger getSum() {
        return sum;
    }

}
