package edu.javaee.ws.client;

import java.math.BigInteger;

/**
 * CalculatorWS Webservice Consumer (JavaSE Client)
 *
 * @author ngj
 */
public class Main {

    public static void main(String[] args) {
        CalculatorWS calculatorWS = new CalculatorWS();
        Calculator port = calculatorWS.getCalculatorIF();
        if (null != port) {
//            long sum = port.add(12, 23);
//            System.out.printf("--- Sum of (12, 23) is '%d' ---", sum);
            BigInteger sumAsBigInteger = port.add(29, 265);
            long sum = sumAsBigInteger.longValue();
            System.out.printf("--- Sum of (29, 265) is '%d' ---", sum);
        }
    }

}
