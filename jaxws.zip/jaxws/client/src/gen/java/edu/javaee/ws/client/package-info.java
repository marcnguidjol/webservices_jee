@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.jaxws.edu")
package edu.javaee.ws.client;
