
package edu.javaee.ws.webclient;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java-Klasse für cardTypeEnum.
 * 
 * <p>Das folgende Schemafragment gibt den erwarteten Content an, der in dieser Klasse enthalten ist.
 * <p>
 * <pre>
 * &lt;simpleType name="cardTypeEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="VISA"/>
 *     &lt;enumeration value="MASTERCARD"/>
 *     &lt;enumeration value="AMERICAN_EXPRESS"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "cardTypeEnum")
@XmlEnum
public enum CardTypeEnum {

    VISA,
    MASTERCARD,
    AMERICAN_EXPRESS;

    public String value() {
        return name();
    }

    public static CardTypeEnum fromValue(String v) {
        return valueOf(v);
    }

}
