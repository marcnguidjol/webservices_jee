@javax.xml.bind.annotation.XmlSchema(namespace = "http://creditcardvalidator.ws.javaee.edu/")
package edu.javaee.ws.webclient;
