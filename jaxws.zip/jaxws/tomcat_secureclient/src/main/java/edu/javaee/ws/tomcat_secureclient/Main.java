package edu.javaee.ws.tomcat_secureclient;

import edu.javaee.ws.client.SayHelloWS;
import edu.javaee.ws.client.SayHelloWSService;

/**
 * Tomcat Client with appl. level auth providing username + password in headers
 * of request
 *
 * @author ngj
 */
public class Main {

    public static void main(String[] args) {
        
        SayHelloWSService sayHelloWSService = new SayHelloWSService();
        SayHelloWS port = sayHelloWSService.getSayHelloWSPort();    
        final String response = port.greet("Marc Nguidjol");
        System.out.println("--- GREETING from secure Tomcat: '" + response + "' ---");
    }

}
