package edu.javaee.ws.tomcat_applicationlevelsecurity;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.http.HTTPException;

/**
 * Greeting WS
 *
 * @author ngj
 */
@WebService
public class SayHelloWS {

    @Resource
    WebServiceContext webServiceContext;

    /**
     * Web service operation
     *
     * @param name
     * @return
     */
    @WebMethod(operationName = "greet")
    public String greet(@WebParam(name = "name") String name) {
        //Check user data in header
        if(!isUserAuthenticated()){
            throw new HTTPException(401);
        }
        int hour = LocalDateTime.now().getHour();
        if (hour > 6 && hour <= 12) {
            return "Guten Morgen '" + name + "'";
        }
        if (hour > 12 && hour <= 18) {
            return "Guten Tag '" + name + "'";
        }
        if (hour > 18 && hour <= 22) {
            return "Guten Abend '" + name + "'";
        }
        if (hour > 22 && hour <= 6) {
            return "Gute Nacht '" + name + "'";
        }
        return "Hallo '" + name + "'";
    }

    private boolean isUserAuthenticated() {
        MessageContext messageContext = this.webServiceContext.getMessageContext();
        if (null != messageContext) {
            Map httpHeaders = (Map) messageContext.get(MessageContext.HTTP_REQUEST_HEADERS);
            if (null != httpHeaders) {
                List userNameList = (List) httpHeaders.get("username");
                List passwordList = (List) httpHeaders.get("password");
                return userNameList.contains("tomcat")
                        && passwordList.contains("tomcat");
            }
        }
        return false;
    }

}
