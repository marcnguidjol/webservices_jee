package edu.javaee.ws.creditcardvalidator;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * CreditCard Model
 *
 * @author ngj
 */
@XmlRootElement
public class CreditCard {

    @NotNull
    @Pattern(regexp = "\\d{16}")
    private String number;
    private String expiryDate;
    @Min(value = 3)
    @Max(value = 3)
    private Integer controlNumber;
    @NotNull
    private CardTypeEnum type;

    public CreditCard() {
    }

    public CreditCard(String number, String expiryDate, Integer controlNumber, CardTypeEnum type) {
        this.number = number;
        this.expiryDate = expiryDate;
        this.controlNumber = controlNumber;
        this.type = type;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Integer getControlNumber() {
        return controlNumber;
    }

    public void setControlNumber(Integer controlNumber) {
        this.controlNumber = controlNumber;
    }

    public CardTypeEnum getType() {
        return type;
    }

    public void setType(CardTypeEnum type) {
        this.type = type;
    }

}
