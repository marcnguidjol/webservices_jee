package edu.javaee.ws.creditcardvalidator;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.validation.Valid;
import org.apache.commons.lang3.StringUtils;

/**
 * CreditCardVlidator WS
 *
 * @author ngj
 */
@WebService
public class CreditCardValidatorWS {

    /**
     * Web service operation
     *
     * @param creditcard
     * @return
     */
    @WebMethod(operationName = "ValidateCreditCard")
    public Boolean validate(@WebParam(name = "creditcard") @Valid final CreditCard creditcard) {
        final String number = creditcard.getNumber();
        int firstIndex = number.length() - 1;
        int lastIndex = number.length();
        final String lastDigit = number.substring(firstIndex, lastIndex);
        if (StringUtils.isNotEmpty(number)) {
            return Integer.parseInt(lastDigit) % 2 == 0;
        }
        return false;
    }

}
