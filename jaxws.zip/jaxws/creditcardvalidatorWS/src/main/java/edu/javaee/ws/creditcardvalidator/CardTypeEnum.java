package edu.javaee.ws.creditcardvalidator;

/**
 * card types
 *
 * @author ngj
 */
public enum CardTypeEnum {

    VISA("Visa"),
    MASTERCARD("MasterCard"),
    AMERICAN_EXPRESS("Amreican Express");

    private final String value;

    private CardTypeEnum(String v) {
        this.value = v;
    }

    public String getValue() {
        return value;
    }

}
